# DRTC Multiplayer - launcher / tester (double-click Launcher.bat)
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
Add-Type @"
using System; using System.Runtime.InteropServices;
public class Win { [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr a, int x, int y, int w, int hgt, uint f);
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); }
"@

$Mod  = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $Mod 'findgame.ps1')
$Game = Find-DrtcGame
if (-not $Game) { [System.Windows.Forms.MessageBox]::Show('Death Road to Canada was not found. Put this folder inside the game folder (next to prog.exe).', 'DRTC Multiplayer') | Out-Null; exit }
$Exe  = Join-Path $Game 'prog.exe'
$Dll  = Join-Path $Mod 'target\i686-pc-windows-msvc\release\steam_wrapper.dll'
if (-not (Test-Path $Dll)) { $Dll = Join-Path $Mod 'steam_wrapper.dll' }
$IsSource = Test-Path (Join-Path $Mod 'Cargo.toml')

function Log($t) { $script:box.AppendText(("[{0}] {1}`r`n" -f (Get-Date -Format HH:mm:ss), $t)) }
function GameRunning { [bool](Get-Process prog -ErrorAction SilentlyContinue) }

function Is-Installed {
    (Test-Path (Join-Path $Game 'steam_wrapper_real.dll')) -and (Test-Path (Join-Path $Game 'deathforth\hack\hack.df'))
}

function Do-Install {
    if (GameRunning) { Log 'Close the game first.'; return }
    if (-not (Test-Path $Dll)) { Log 'No built DLL found. Use "Build + install" (needs Rust).'; return }
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Mod 'install.ps1') | ForEach-Object { Log $_ }
    Update-Status
}

function Do-Build {
    if (GameRunning) { Log 'Close the game first.'; return }
    Log 'Building (cargo)...'
    Push-Location $Mod
    $out = & cargo +stable-x86_64-pc-windows-msvc build --release 2>&1 | Select-Object -Last 6
    Pop-Location
    $out | ForEach-Object { Log "$_" }
    Do-Install
}

function Do-Uninstall {
    if (GameRunning) { Log 'Close the game first.'; return }
    & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Mod 'uninstall.ps1') | ForEach-Object { Log $_ }
    Update-Status
}

function Kill-All { Get-Process prog -ErrorAction SilentlyContinue | Stop-Process -Force; Log 'All game windows closed.'; Update-Status }

# Start one game process. $name = test-instance name (own save profile + own log), or '' for a normal launch.
function Start-Game([string]$name, [bool]$mp, [string]$extra) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $Exe
    $psi.WorkingDirectory = $Game
    $psi.UseShellExecute = $false
    if ($mp) { $psi.EnvironmentVariables['DRTC_MP'] = '1' }
    if ($name) {
        $prof = Join-Path $Mod "test\prof$name"
        New-Item -ItemType Directory -Force (Join-Path $prof '.madgarden\DR2C') | Out-Null
        $psi.EnvironmentVariables['APPDATA'] = $prof
        $psi.EnvironmentVariables['MP_NAME'] = $name
        $psi.EnvironmentVariables['DRTC_MP_NAME'] = $name
    }
    if ($extra) { $psi.EnvironmentVariables['MP_EXTRA'] = $extra }
    return [System.Diagnostics.Process]::Start($psi)
}

function Place-Window($proc, [int]$x, [int]$y) {
    for ($i = 0; $i -lt 60; $i++) {
        Start-Sleep -Milliseconds 250
        $proc.Refresh()
        if ($proc.HasExited) { return }
        if ($proc.MainWindowHandle -ne [IntPtr]::Zero) {
            [Win]::SetWindowPos($proc.MainWindowHandle, [IntPtr]::Zero, $x, $y, 0, 0, 0x0001 -bor 0x0004) | Out-Null  # SWP_NOSIZE|NOZORDER
            return
        }
    }
}

function Prep {
    if (-not (Is-Installed)) { Log 'Mod is not installed - click "Install mod" first.'; return $false }
    if (GameRunning) { Log 'Closing the game window(s) that were already running...'; Get-Process prog -ErrorAction SilentlyContinue | Stop-Process -Force; Start-Sleep -Seconds 2 }
    return $true
}

# Add one more window (P2) that joins a host on this PC. Does not close existing windows.
function Launch-Second {
    if (-not (Is-Installed)) { Log 'Mod is not installed - click "Install mod" first.'; return }
    $n = 'P2'
    if (Get-Process prog -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -ne '' } | Measure-Object | Where-Object { $_.Count -ge 2 }) { Log 'Two or more windows are already running.'; return }
    $b = Start-Game $n $true 'join:127.0.0.1:7777'
    Place-Window $b 1290 0
    Log 'Started window P2: it joins 127.0.0.1:7777 automatically. Make sure the other window has HOST A GAME -> OPEN LOBBY open (it keeps retrying for about 2 minutes).'
}

function Launch-Solo   { if (Prep) { Start-Game '' $false '' | Out-Null; Log 'Started the game normally (mod installed; use the MULTIPLAYER title button).' } }
function Launch-One    {
    if (Prep) { Start-Game '' $true '' | Out-Null; Log 'Started ONE window in multiplayer mode (your real profile is not touched). Choose HOST A GAME -> OPEN LOBBY -> START ALONE.' }
}
function Launch-Two([bool]$auto) {
    if (-not (Prep)) { return }
    $hostExtra = ''; $joinExtra = ''
    if ($auto) { $hostExtra = 'host:7777;start:9'; $joinExtra = 'join:127.0.0.1:7777' }
    $a = Start-Game 'P1' $true $hostExtra
    Start-Sleep -Seconds 2
    $b = Start-Game 'P2' $true $joinExtra
    Place-Window $a 0 0
    Place-Window $b 1290 0
    if ($auto) { Log 'Started 2 windows; P1 hosts, P2 joins, game starts automatically in ~10 s.' }
    else { Log 'Started 2 windows. In P1: HOST A GAME -> OPEN LOBBY. In P2: JOIN A GAME -> 127.0.0.1 -> CONNECT. Then START GAME in P1.' }
    Log 'Keyboard goes to the window you click on. Arrows + Z/X/C. F10 = multiplayer menu.'
}

function Read-GithubCfg {
    $f = Join-Path $Mod 'github.cfg'
    if (-not (Test-Path $f)) { return $null }
    $c = @{}
    foreach ($l in Get-Content $f) { if ($l -match '^\s*(\w+)\s*=\s*(.*)$') { $c[$Matches[1]] = $Matches[2].Trim() } }
    return $c
}

# Download the latest mod release from the public "playable" GitHub repo and reinstall it.
function Update-FromGithub {
    $c = Read-GithubCfg
    if (-not $c) { Log 'No github.cfg next to the launcher - updates come from the setup file.'; return }
    if (GameRunning) { Log 'Close the game first (or click "Close all game windows").'; return }
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $h = @{ 'User-Agent' = 'drtc-mp-launcher'; 'Cache-Control' = 'no-cache' }
    $base = "https://raw.githubusercontent.com/$($c.owner)/$($c.repo)/$($c.branch)/release"
    $tmp = Join-Path $env:TEMP 'DRTC-Multiplayer-update.zip'
    try {
        $ver = (Invoke-WebRequest -UseBasicParsing -Headers $h -Uri "$base/version.txt").Content.Trim()
        Log "Latest version on GitHub: $ver - downloading..."
        Invoke-WebRequest -UseBasicParsing -Headers $h -Uri "$base/DRTC-Multiplayer.zip" -OutFile $tmp
    } catch { Log "Download failed: $($_.Exception.Message)"; return }
    Expand-Archive -Path $tmp -DestinationPath (Split-Path -Parent $Mod) -Force
    Remove-Item $tmp -Force -ErrorAction SilentlyContinue
    Do-Install
    Log "Updated to $ver. Close and reopen the launcher to use the new launcher version."
}

function Open-Logs {
    $f = Get-ChildItem $Game -Filter 'mp_mod*.log' | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($f) { Start-Process notepad.exe $f.FullName } else { Log 'No log files yet.' }
}

#UI_START
$form = New-Object System.Windows.Forms.Form
$form.Text = 'Death Road to Canada - Multiplayer launcher'
$form.Size = New-Object System.Drawing.Size(560, 690)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'; $form.MaximizeBox = $false
$form.BackColor = [System.Drawing.Color]::FromArgb(20, 24, 40)
$font = New-Object System.Drawing.Font('Segoe UI', 10)

$status = New-Object System.Windows.Forms.Label
$status.Location = '16,12'; $status.Size = '520,24'; $status.ForeColor = 'White'
$status.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($status)

function Update-Status {
    if (Is-Installed) { $status.Text = 'Mod: INSTALLED'; $status.ForeColor = [System.Drawing.Color]::LightGreen }
    else { $status.Text = 'Mod: not installed'; $status.ForeColor = [System.Drawing.Color]::Orange }
}

$y = 44
function Add-Button($text, $action, $tip) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text; $b.Location = New-Object System.Drawing.Point(16, $script:y); $b.Size = '520,38'
    $b.Font = $font; $b.FlatStyle = 'Flat'; $b.BackColor = [System.Drawing.Color]::FromArgb(40, 70, 160); $b.ForeColor = 'White'
    $b.Add_Click($action)
    (New-Object System.Windows.Forms.ToolTip).SetToolTip($b, $tip)
    $form.Controls.Add($b)
    $script:y += 44
}

Add-Button 'Install mod (copy DLL + script into the game)'      { Do-Install }   'Backs up steam_wrapper.dll as steam_wrapper_real.dll'
if ($IsSource) { Add-Button 'Build + install (needs Rust, rebuilds from source)' { Do-Build } 'cargo build --release, then install' }
Add-Button 'Uninstall mod (restore original game files)'         { Do-Uninstall } 'Restores the original steam_wrapper.dll'
Add-Button 'PLAY - normal game (solo)'                           { Launch-Solo }  'Normal game with the MULTIPLAYER title button'
Add-Button 'TEST - 1 window (multiplayer mode, play alone)'      { Launch-One }   'Single window in multiplayer mode'
Add-Button 'TEST - 2 windows, manual lobby (host + join by hand)' { Launch-Two $false } 'Two windows with separate profiles'
Add-Button 'TEST - 2 windows, AUTO connect + start'              { Launch-Two $true }  'P1 hosts, P2 joins, game starts by itself'
Add-Button 'TEST - add 2nd window now (P2 joins the running host)' { Launch-Second } 'Use when one window is already open as host'
Add-Button 'Close all game windows'                              { Kill-All }
Add-Button 'Open latest log (mp_mod*.log)'                       { Open-Logs }
if (Read-GithubCfg) { Add-Button 'Update mod from GitHub (download latest version)' { Update-FromGithub } 'Downloads the newest release from the mod repo' }

$script:box = New-Object System.Windows.Forms.TextBox
$box.Multiline = $true; $box.ReadOnly = $true; $box.ScrollBars = 'Vertical'
$boxH = 690 - $y - 50
$box.Location = New-Object System.Drawing.Point(16, $y); $box.Size = New-Object System.Drawing.Size(520, $boxH)
$box.BackColor = [System.Drawing.Color]::FromArgb(10, 12, 22); $box.ForeColor = 'Gainsboro'; $box.Font = New-Object System.Drawing.Font('Consolas', 9)
$form.Controls.Add($box)

Update-Status
Log "Game folder: $Game"
$form.Add_Shown({ $form.Activate() })
[void]$form.ShowDialog()
