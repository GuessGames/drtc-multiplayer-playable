DEATH ROAD TO CANADA - ONLINE MULTIPLAYER MOD
==============================================

Play the same run together over the internet (RadminVPN, LAN or any IP).
Every player needs their own copy of Death Road to Canada (Steam, Windows version)
and the SAME version of this mod.

INSTALL
-------
1. Close the game.
2. Unzip this folder INTO your game folder, so it looks like:
      ...\steamapps\common\DeathRoadToCanada\DRTC-Multiplayer\Install.bat
   (Steam: right-click the game -> Manage -> Browse local files.)
3. Double-click Install.bat.
   Your original steam_wrapper.dll is kept as steam_wrapper_real.dll.

PLAY TOGETHER
-------------
1. Everyone joins the same RadminVPN network (or is on the same LAN).
2. Start the game (normally, from Steam is fine).
3. On the title screen click MULTIPLAYER -> RESTART IN MULTIPLAYER.
   (Or double-click Launcher.bat -> "TEST - 1 window".)
4. Host: HOST A GAME -> OPEN LOBBY. Tell friends the green 26.x.x.x address.
   Friends: JOIN A GAME -> type that address -> CONNECT.
5. Host presses START GAME when everyone is in the list.

Controls: your normal keyboard/controller controls, mouse works too.
F10 = multiplayer menu (leave the session).

Multiplayer mode uses its own separate save profile - your normal saves
and unlocks are not touched.

TEST ON ONE PC
--------------
Launcher.bat -> "TEST - 2 windows, AUTO connect + start".
Click a window to control its player.

UNINSTALL
---------
Close the game, double-click Uninstall.bat.
(Steam "Verify integrity of game files" also removes the mod.)

PROBLEMS
--------
Logs are written to the game folder: mp_mod.log (send it to the mod author).
If a red "OUT OF SYNC" banner appears, send the logs of ALL players.
If the host's firewall asks, allow prog.exe on private networks
(default port 7777 TCP).
