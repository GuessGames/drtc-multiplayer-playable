$ErrorActionPreference = 'Stop'
$mod = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $mod 'findgame.ps1')
$game = Find-DrtcGame
if (-not $game) { throw "Death Road to Canada was not found." }
if (Get-Process prog -ErrorAction SilentlyContinue) { throw "Close the game first." }
$real = Join-Path $game 'steam_wrapper_real.dll'
if (Test-Path $real) { Move-Item $real (Join-Path $game 'steam_wrapper.dll') -Force }
Remove-Item (Join-Path $game 'deathforth\hack') -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "Uninstalled (original steam_wrapper.dll restored, hack folder removed) from: $game"
