# Installs the DRTC multiplayer mod into the game folder (reversible with uninstall.ps1).
# Works both from the source folder (uses the freshly built DLL) and from the release package (uses the bundled DLL).
$ErrorActionPreference = 'Stop'
$mod = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $mod 'findgame.ps1')
$game = Find-DrtcGame
if (-not $game) { throw "Death Road to Canada was not found. Put this folder inside the game folder (next to prog.exe) and run again." }

$dll = Join-Path $mod 'target\i686-pc-windows-msvc\release\steam_wrapper.dll'
if (-not (Test-Path $dll)) { $dll = Join-Path $mod 'steam_wrapper.dll' }
if (-not (Test-Path $dll)) { throw "steam_wrapper.dll (the mod) is missing from $mod" }
$df = Join-Path $mod 'forth\hack.df'
if (-not (Test-Path $df)) { $df = Join-Path $mod 'hack.df' }
if (-not (Test-Path $df)) { throw "hack.df is missing from $mod" }

if (Get-Process prog -ErrorAction SilentlyContinue) { throw "Close the game first." }
$orig = Join-Path $game 'steam_wrapper.dll'
$real = Join-Path $game 'steam_wrapper_real.dll'
if (-not (Test-Path $real)) { Move-Item $orig $real }          # first install: keep the original
Copy-Item $dll $orig -Force
New-Item -ItemType Directory -Force (Join-Path $game 'deathforth\hack') | Out-Null
Copy-Item $df (Join-Path $game 'deathforth\hack\hack.df') -Force
Write-Host "Installed into: $game"
Write-Host "Log files: $game\mp_mod*.log"
