# Locates the Death Road to Canada folder (the one containing prog.exe).
# 1) the folder above this script (mod placed inside the game folder)
# 2) every Steam library listed in Steam's libraryfolders.vdf
function Find-DrtcGame {
    $here = Split-Path -Parent $PSCommandPath
    $up = Split-Path -Parent $here
    if (Test-Path (Join-Path $up 'prog.exe')) { return $up }
    if (Test-Path (Join-Path $here 'prog.exe')) { return $here }
    $roots = @()
    foreach ($k in 'HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam') {
        try {
            $p = Get-ItemProperty $k -ErrorAction Stop
            if ($p.SteamPath) { $roots += $p.SteamPath }
            if ($p.InstallPath) { $roots += $p.InstallPath }
        } catch {}
    }
    $libs = @()
    foreach ($r in $roots | Select-Object -Unique) {
        $libs += $r
        $vdf = Join-Path $r 'steamapps\libraryfolders.vdf'
        if (Test-Path $vdf) {
            foreach ($m in [regex]::Matches((Get-Content $vdf -Raw), '"path"\s+"([^"]+)"')) {
                $libs += $m.Groups[1].Value.Replace('\\', '\')
            }
        }
    }
    foreach ($l in $libs | Select-Object -Unique) {
        $g = Join-Path $l 'steamapps\common\DeathRoadToCanada'
        if (Test-Path (Join-Path $g 'prog.exe')) { return $g }
    }
    return $null
}
